let x, y; // posição do círculo
let raio = 30;
let pontos = 0;
let tempoRestante = 30;
let jogoAtivo = true;

function setup() {
  createCanvas(400, 400);
  novaPosicao();
  frameRate(60);
  setInterval(() => {
    if (jogoAtivo) {
      tempoRestante--;
      if (tempoRestante <= 0) {
        jogoAtivo = false;
      }
    }
  }, 1000); // a cada 1 segundo
}

function draw() {
  background(220);

  if (jogoAtivo) {
    fill(0, 200, 100);
    ellipse(x, y, raio * 2);

    fill(0);
    textSize(16);
    text("Pontos: " + pontos, 10, 20);
    text("Tempo: " + tempoRestante + "s", 10, 40);
  } else {
    textSize(32);
    fill(0);
    textAlign(CENTER, CENTER);
    text("Fim de jogo!", width / 2, height / 2 - 20);
    textSize(24);
    text("Pontos: " + pontos, width / 2, height / 2 + 20);
  }
}

function mousePressed() {
  if (jogoAtivo) {
    let d = dist(mouseX, mouseY, x, y);
    if (d < raio) {
      pontos++;
      novaPosicao();
    }
  }
}

function novaPosicao() {
  x = random(raio, width - raio);
  y = random(raio, height - raio);
}
